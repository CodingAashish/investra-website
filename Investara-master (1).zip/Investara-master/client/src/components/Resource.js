import React, { Component } from "react";
// import FAQ from "./FAQ";
export class Resource extends Component {
  render() {
    return (
      <div className="h-100 w-100">
        <h1 className="text-center " style={{ height: "100vh" }}>
          Resources
        </h1>
      </div>
    );
  }
}

export default Resource;
